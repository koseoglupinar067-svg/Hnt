Nuke.pl full GUI source reference

The complete non-binary GUI source is included here so the Android UI can be
ported accurately. The Windows/C++ renderer itself is not directly executable
on Android. Android must reproduce the same layout/interaction using the
existing Kotlin/Compose UI.

Target:
- same category/module layout
- same sizing/spacing hierarchy
- same settings controls
- same click/long-press behavior
- transparent/neon styling requested for NoxNo
- preserve NoxNo touch passthrough when GUI is closed
